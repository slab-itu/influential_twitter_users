# -*- coding: utf-8 -*-
"""
Created on Sun Jun 12 14:03:32 2016

@author: anam
"""
import numpy as np
from scipy import interp
import matplotlib.pyplot as plt
import pandas as pd
from sklearn import svm, datasets
from sklearn.metrics import roc_curve, auc
from sklearn.cross_validation import StratifiedKFold
from sklearn.ensemble import RandomForestClassifier
from sklearn.ensemble import ExtraTreesClassifier
from sklearn.feature_selection import SelectFromModel
from sklearn.tree import DecisionTreeClassifier
from sklearn.neighbors import KNeighborsClassifier
from sklearn.discriminant_analysis import LinearDiscriminantAnalysis
from sklearn.naive_bayes import GaussianNB
###############################################################################


# import some data 
mydata = pd.read_csv("C:/Users/Asma/Desktop/Paper1/27-JULY-2018/Baseline.csv")
y = mydata["TOP_50_PAPERS"]  #provided your csv has header row, and the label column is named "Label")
##select all but the last column as data
X = mydata.ix[:,:-1]
X=X.iloc[:,:]



cv = StratifiedKFold(y, n_folds=10)

classifier1 = svm.SVC(kernel='rbf',gamma=0.001, C=100, probability=True, class_weight ='balanced')

classifier2 = RandomForestClassifier(n_estimators=50,
                                  class_weight="auto",
                                  criterion='gini',
                                  bootstrap=True,
                                  max_features=0.5,
                                  min_samples_split=1,
                                  min_samples_leaf=10,
                                  max_depth=100,
                                  n_jobs=1)



mean_tpr1 = 0.0
mean_fpr1 = np.linspace(0, 1, 100)

mean_tpr2 = 0.0
mean_fpr2 = np.linspace(0, 1, 100)


all_tpr = []

for i, (train, test) in enumerate(cv):
    x_train=X[train[0]:train[len(train)-1]]
    x_test=X[test[0]:test[len(test)-1]]
    y_train= y[train[0]:train[len(train)-1]]
    y_test=y[test[0]:test[len(test)-1]]
    
    probas1_ = classifier1.fit(x_train, y_train).predict_proba( x_test)
    probas2_ = classifier2.fit(x_train, y_train).predict_proba( x_test)

    
    
    fpr2, tpr2, thresholds2 = roc_curve(y_test, probas2_[:, 1])
    mean_tpr2 += interp(mean_fpr2, fpr2, tpr2)
    mean_tpr2[0] = 0.0


    fpr1, tpr1, thresholds1 = roc_curve(y_test, probas1_[:, 1])
    mean_tpr1 += interp(mean_fpr1, fpr1, tpr1)
    mean_tpr1[0] = 0.0


plt.plot([0, 1], [0, 1], color=(0.6, 0.6, 0.6))

mean_tpr1 /= len(cv)
mean_tpr1[-1] = 1.0
mean_auc1 = auc(mean_fpr1, mean_tpr1)

mean_tpr2 /= len(cv)
mean_tpr2[-1] = 1.0
mean_auc2 = auc(mean_fpr2, mean_tpr2)



plt.plot(mean_fpr1, mean_tpr1, label='Mean ROC SVM (area = %0.2f)' % mean_auc1, lw=2,color="blue")
plt.plot(mean_fpr2, mean_tpr2, label='Mean ROC Random Forest (area = %0.2f)' % mean_auc2, lw=2,color="green")





plt.xlim([-0.02, 1.0])
plt.ylim([-0.02, 1.05])
plt.xlabel('False Positive Rate')
plt.ylabel('True Positive Rate')
plt.title('Receiver operating characteristic')
plt.legend(loc="upper left", bbox_to_anchor=(1,1))
plt.show()