# -*- coding: utf-8 -*-
"""
Created on Wed Jul 26 14:43:05 2017

@author: Asma
"""

# -*- coding: utf-8 -*-
"""
Created on Sun Jun 12 14:03:32 2016


"""
import numpy
from scipy import interp
import matplotlib.pyplot as plt
import pandas as pd
from sklearn import svm
from sklearn.metrics import auc
from sklearn.cross_validation import StratifiedKFold
from sklearn.metrics import precision_recall_curve
from sklearn.metrics import average_precision_score
from sklearn.ensemble import RandomForestClassifier
from sklearn.feature_selection import SelectFromModel
from sklearn.neighbors import KNeighborsClassifier
from sklearn.tree import DecisionTreeClassifier
from sklearn.naive_bayes import GaussianNB


# import some data to play with
mydata = pd.read_csv("C:/Users/Asma/Desktop/Paper1/27-JULY-2018/Baseline.csv")
y = mydata["TOP_50_PAPERS"]  #provided your csv has header row, and the label column is named "Label"
n_points=len(mydata)
##select all but the last column as data
X = mydata.ix[:,:-1]
#X=X.iloc[:,:]

##################################


cv = StratifiedKFold(y, n_folds=10)

y_real1 = []
y_proba1 = []

y_real2 = []
y_proba2 = []


classifier1 = svm.SVC(kernel='rbf',gamma=0.001, C=100, probability=True, class_weight ='balanced')
classifier2 = RandomForestClassifier(n_estimators=50,
                                 class_weight="auto",
                                 criterion='gini',
                                 bootstrap=True,
                                 max_features=0.5,
                                 min_samples_split=1,
                                 min_samples_leaf=5,
                                 max_depth=100,
                                 n_jobs=1)


for i, (train, test) in enumerate(cv):
    x_train=X[train[0]:train[len(train)-1]]
    x_test=X[test[0]:test[len(test)-1]]
    y_train= y[train[0]:train[len(train)-1]]
    y_test=y[test[0]:test[len(test)-1]]
    probas1_ = classifier1.fit(x_train, y_train).predict_proba( x_test)
    probas2_ = classifier2.fit(x_train, y_train).predict_proba( x_test)


    y_real1.append(y_test)
    y_proba1.append(probas1_[:, 1])
    
    y_real2.append(y_test)
    y_proba2.append(probas2_[:, 1])

    
y_real1 = numpy.concatenate(y_real1)
y_proba1 = numpy.concatenate(y_proba1)

y_real2 = numpy.concatenate(y_real2)
y_proba2 = numpy.concatenate(y_proba2)



precision1, recall1, _ = precision_recall_curve(y_real1, y_proba1)
precision2, recall2, _ = precision_recall_curve(y_real2, y_proba2)

lab = 'Mean PR SVM (area = %0.2f)' % (auc(recall1, precision1))
lab2 = 'Mean PR Random Forest (area = %0.2f)' % (auc(recall2, precision2))


plt.plot(recall1, precision1, label=lab, lw=2, color='blue') 
plt.plot(recall2, precision2, label=lab2, lw=2, color='green') 

plt.xlim([0, 1.000000001])
plt.ylim([0, 1.05])
plt.grid(True)
plt.xlabel('Recall')
plt.ylabel('Precision')
plt.title('Precision Recall curve')
plt.rcParams['axes.facecolor']='white'
plt.legend(loc="upper left", bbox_to_anchor=(1,1))
plt.show()


    
    
    